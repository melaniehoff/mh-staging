# PLAN

## TASK: GENERAL REFACTOR

- Get lichen css into own invisible file
- split applyContent into sub routines:
  - handle input
  - handle render of preview

## TASK: Edit and preview css

- make sensible flow control of render preview

## TASK: fix markdown missings

- [x] markdown cheatsheet
- [x] help
- [ ] missing title
- [x] logic only on \*.gmi (e.g. go back arrow in layout)
- [x] extended markdown?
- [ ] Insert link logic still uses gemtext syntax 

## TASK: implement markdown header and footer files

## TASK: ask for overwriting instead of throwing error

## TASK: upload multiple files

## TASK: make scripler themes available
